# Interpreter
Concepts of Programming Languages Project
Team: David Waldorf, Richard Luthringshauser, William Shu
Date: 9/21/2018
Changes: 
Parser: Added getForStatement() method on line 376.
	 Added FOR_TOK lookup at line 91, and 197
Added ForStatement class to be able to handle for statements