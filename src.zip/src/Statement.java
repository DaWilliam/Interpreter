
public interface Statement
{

	/**
	 *  statement has been executed
	 */
	public void execute();
	
}
