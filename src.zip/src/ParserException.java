
public class ParserException extends Exception
{

	private static final long serialVersionUID = 2284169084900414715L;

	public ParserException(String message)
	{
		super (message);
	}

}
