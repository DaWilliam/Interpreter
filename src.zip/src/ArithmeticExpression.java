
public interface ArithmeticExpression
{
	
	/**
	 * @return value of the arithmetic expression
	 */
	public int evaluate();

}
