
public class LexicalException extends Exception
{

	private static final long serialVersionUID = 8968627285835792944L;

	public LexicalException(String message)
	{
		super (message);
	}

}
